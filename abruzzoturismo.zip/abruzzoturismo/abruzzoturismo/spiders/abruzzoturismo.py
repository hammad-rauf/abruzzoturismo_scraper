from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor

class AbruzzoturismoSpider(CrawlSpider):

    name = "abruzzoturismo"
    
    start_urls=['https://abruzzoturismo.it/it/dove-dormire-0']
    

    def parse(self,response):


        for data in response.css(".col-lg-4.col-md-4.col-sm-4.col-xs-12 .views-field.views-field-nothing"):
           
            name = data.css(".team-name::text").extract_first()

            if name:
                name = name.replace("\n",'')
                name = name.strip()

            temp_data = data.css(".socials::text").extract()
            
            email = None
            for temp in temp_data:

                if '@' in temp:
                    email = temp
                    email = email.replace("\n",'')
                    email = email.strip()
                    break

            if email:
                yield{
                    'name':name,
                    'email':email
                }
        
        
        next_page = response.css(".pager2 .pager__item.pager__item--next a::attr(href)").extract_first()
        
        if next_page:
            yield response.follow(url=next_page,callback=self.parse)
            
